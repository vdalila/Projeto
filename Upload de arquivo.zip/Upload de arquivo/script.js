const fileInput = document.getElementById('fileInput');
const outputDiv = document.getElementById('output');

fileInput.addEventListener('change', function(event) {
    const file = event.target.files[0];
    
    if (file && file.type === "text/plain") {
        const reader = new FileReader();

        reader.onload = function(e) {
            outputDiv.textContent = e.target.result; 
        };

        reader.readAsText(file); 
    } else {
        alert('Por favor, selecione um arquivo .txt válido.');
    }
});
